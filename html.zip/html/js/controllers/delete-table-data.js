console.log("delete-table-data Running...");

function deleteRecord(recordId){
  alert("Seguro que deseas borrar el record: "+recordId);
}
